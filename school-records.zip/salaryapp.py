import streamlit as st

def run_salary_app():
    st.title("👨‍🏫 Teacher Salary Manager")
    st.info("Salary module under construction.")